#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
struct student
{
 char en[13];
 char f_name[10];
 char m_name[10];
 char l_name[10];
 char gen[7];
 char mail[30];
 char m_no[15];
 char cast[10];
 char religion[20];
 char aadhar_card[20];
 char samagra_id[20];
 struct dob
 {
  int dd,mm,yy;
 }dob;
 struct address
 {
  long int  pin;
  char house_no[10];
  char street[20];
  char city[20];
  char district[20];
  char state[20];
  char country[20];
 }ad;
 struct p_exam_d
 {
  double tenth;
  double towlth;
  double jee;
 }p_exam_d;
 struct firstyear
 {
  struct firstsem
  {
   char res[10];
   double per;
   char fail_sn[100];
   char fail_sc[50];
   }fsem;
  struct secondsem
  {
   char res[10];
   double per;
   char fail_sn[100];
   char fail_sc[50];
    }ssem;
 }fy;
 struct secondyear
 {
  struct thirdsem
  {
   char res[10];
   double per;
   char fail_sn[100];
   char fail_sc[50];
   }tsem;
  struct fourthsem
  {
   char res[10];
   double per;
   char fail_sn[100];
   char fail_sc[50];
   }fosem ;
 }sy;
 struct thirdyear
 {
  struct fifthtsem
  {
   char res[10];
   double per;
   char fail_sn[100];
   char fail_sc[50];
   }ffsem;
  struct sixthsem
  {
   char res[10];
   double per;
   char fail_sn[100];
   char fail_sc[50];
   }sixsem;
 }ty;
 struct fourthyear
 {
  struct seventhsem
  {
   char res[10];
   double per;
   char fail_sn[100];
   char fail_sc[50];
   }sevsem;
  struct eigthsem
  {
   char res[10];
   double per;
   char fail_sn[100];
   char fail_sc[50];
   }esem;
 }foy;
 struct parent
 {
  char father_n[20];
  char f_occup[30];
  char f_no[11];
  char mother_n[20];
  char m_occup[30];
  char m_no[11];
  double income;
 }parent;
 struct college
 {
  int year,sem;
  char college_name[70];
  char course_name[10];
  char branch[30];
  char dept_name[30];
  char ad_status[10];
  struct ad_date
  {
  int dd,mm,yy;
  }ad_date;
  struct hostel_s
  {
   char h[20];
   int no;
  }hs;
 }college;
 struct acc_d
 {
  char b_name[50];
  char acc_no[25];
  char branch_name[50];
  char ifsc[20];
 }acc_d;
}s;
void password(void)
{
 char d[10]="pass";
 char ch,pass[10],e[10]="exit";
 int i=0;
  system("CLS");
 printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t\t\t WELCOME To Student Record Management System \n");
 printf("\n\t\t\t\t\t\t\t*****************************************************************************");
 printf("\n\n\n\t\t\t\t\t\t\t\t\t Project Name :- STUDENT RECORD MANAGEMENT SYSTEM");
 printf("\n\n\t\t\t\t\t\t\t\t\t I/C Project :- Prof.Manoj Kumar Soni Sir");
 printf("\n\n\t\t\t\t\t\t\t\t\t Project Guide :- Prof.Sachin Mahajan Sir");
 printf("\n\n\n\t\t\t\t\t\t\t\t\t Team Member Name :-");
 printf(" Mayur Jaiswal   / 0805IT171017");
 printf("\n\t\t\t\t\t\t\t\t\t\t\t     Manish Kewat    / 0805IT171016");
 printf("\n\t\t\t\t\t\t\t\t\t\t\t     Husain Mansoori / 0805IT171011");
 printf("\n\n\n\t\t\t\t\t\t\t*****************************************************************************");
 printf("\n\n\n\t\t\t\t\t\t\t\t\t\t Enter Password:(pass/exit)");
 while(i<4)
 {
  fflush(stdin);
  ch=getch();
  if(ch)
  {
   putch('*');
   pass[i] = ch;
   i++;
   }
  }
 pass[i] = '\0';
 if(strcmp(pass,e)==0)
   exit(1);
 if(strcmp(pass,d)==0)
 {
  printf("\n\n\t\t\t\t\t\t\t\t\t\t Password matched!!");
  printf("\n\n\t\t\t\t\t\t\t\t\t\t Press any key to countinue.....");
  getch();
   system("CLS");
 }
 else
 {
 printf("\n\n\t\t\t\t\t\t\t\t\t\t\t\aWarning!! \n\t\t\t\t\t\t\t\t\t   Incorrect Password");
 getch();
  system("CLS");
 password();
  }
}

FILE *fp;

void insert(char *en)
{
 int isFound=1;
 system("CLS");
 fp=fopen("student.txt","ab+");
 if(fp==NULL)
 {
  printf("\n\t\t\t\t\t\t\t\t\t\t File not open\n");
  exit(1);
 }
while(fread(&s,sizeof(s),1,fp) == 1)
{
	if(strcmp(en,s.en) == 0)
	{
		isFound = 0;
		break;
	}
}
if(isFound==1)
{
 printf("\n\n\n\n\t\t\t\t\t\t\t\t\t\t Note: Enter Any Entites Small Case Letter Only ");
 printf("\n\t\t\t\t\t\t************************************************************************************************");
 strcpy(s.en,en);
 printf("\n\t\t\t\t\t\t\t\t\t\t Enter First Name:");
 gets(s.f_name);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\t You have any middle name(y/n):");
 if('y'==getch())
 {
 printf("\n\t\t\t\t\t\t\t\t\t\t Enter Middle Name:");
 gets(s.m_name);
 fflush(stdin);
 }
 printf("\n\n\t\t\t\t\t\t\t\t\t\t Enter Last name:");
 gets(s.l_name);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\t Enter Date of Birth(dd/mm/yyyy) :");
 scanf("%d/%d/%d/",&s.dob.dd,&s.dob.mm,&s.dob.yy);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\t Enter Gender (male/female):");
 gets(s.gen);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\t Enter Email:");
 gets(s.mail);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\t Enter Mobile Number:");
 gets(s.m_no);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\t Enter House Number:");
 gets(s.ad.house_no);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\t Enter Street:");
 gets(s.ad.street);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\t Enter Pin Code:");
 scanf("%ld",&s.ad.pin);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\t Enter City:");
 gets(s.ad.city);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\t Enter District :");
 gets(s.ad.district);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter state:");
 gets(s.ad.state);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Country:");
 gets(s.ad.country);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Category (general/obc/st/sc):");
 gets(s.cast);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Religion :");
 gets(s.religion);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Father Name :");
 gets(s.parent.father_n);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Father occupation :");
 gets(s.parent.f_occup);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Father Mobile Number :");
 gets(s.parent.f_no);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Mother Name :");
 gets(s.parent.mother_n);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Mother occupation :");
 gets(s.parent.m_occup);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Mother Mobile Number:");
 gets(s.parent.m_no);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Income :");
 scanf("%lf",&s.parent.income);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Aadhar card Number :");
 gets(s.aadhar_card);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Samagra Id :");
 gets(s.samagra_id);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter 10th Persentage :");
 scanf("%lf",&s.p_exam_d.tenth);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter 12th persentage :");
 scanf("%lf",&s.p_exam_d.towlth);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter JEE Marks :");
 scanf("%lf",&s.p_exam_d.jee);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Collage Name :");
 gets(s.college.college_name);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Course Name :");
 gets(s.college.course_name);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Current Year(1/2/3/4):");
 scanf("%d",&s.college.year);
 fflush(stdin);
 if(s.college.year==1)
 {
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Current Semester(1/2):");
 scanf("%d",&s.college.sem);
 fflush(stdin);
 }
 else if(s.college.year==2)
 {
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Current Semester(3/4):");
 scanf("%d",&s.college.sem);
 fflush(stdin);
 }
 else if(s.college.year==3)
 {
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Current Semester(5/6):");
 scanf("%d",&s.college.sem);
 fflush(stdin);
 }
 else if(s.college.year==4)
 {
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Current Semester(7/8):");
 scanf("%d",&s.college.sem);
 fflush(stdin);
 }
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Branch(it/cs/ce/me/ex):");
 gets(s.college.branch);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Department Name(cs/ce/me/ex):");
 gets(s.college.dept_name);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Admission Status (gen/tfw) :");
 gets(s.college.ad_status);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Admission Date (dd/mm/yyyy):");
 scanf("%d/%d/%d",&s.college.ad_date.dd,&s.college.ad_date.mm,&s.college.ad_date.yy);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Hostel Status Press key \n\t\t\t\t\t\t\t\t\t\t1.Hostler\n\t\t\t\t\t\t\t\t\t\t2.Day Scholar\n\t\t\t\t\t\t\t\t\t\t");
 printf("Enter Your CHooice");
 if('1'==getch())
 {
   strcpy(s.college.hs.h,"hostler");
   printf("\n\t\t\t\t\t\t\t\t\t\tEnter Room No:");
   scanf("%d",&s.college.hs.no);
   fflush(stdin);
 }
 else
 {
   strcpy(s.college.hs.h,"day scholer");
   printf("\n\t\t\t\t\t\t\t\t\t\tEnter Bus No:");
   scanf("%d",&s.college.hs.no);
   fflush(stdin);
 }

 if(1==s.college.year);
 if(2==s.college.year)
 {
  printf("\n\t\t\t\t\t\t\t\t\t\tEnter First Semester Result (pass/fail) :");
  abc1:
  gets(s.fy.fsem.res);
  if(strcmp(s.fy.fsem.res,"pass")==0|| strcmp(s.fy.fsem.res,"PASS")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter First sem persentce :");
    scanf("%lf",&s.fy.fsem.per);
    fflush(stdin);
  }
  else if(strcmp(s.fy.fsem.res,"fail")==0|| strcmp(s.fy.fsem.res,"FAIL")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject name :");
    gets(s.fy.fsem.fail_sn);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject Code :");
    gets(s.fy.fsem.fail_sc);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter First sem persentce :");
    scanf("%lf",&s.fy.fsem.per);
    fflush(stdin);
  }
  else
  {
   printf("Valid result(pass/fail) :");
   goto abc1;
  }
  printf("\n\t\t\t\t\t\t\t\t\t\tEnter Second Semester Result (pass/fail) :");
  abc2:
  gets(s.fy.ssem.res);
  if(strcmp(s.fy.ssem.res,"pass")==0|| strcmp(s.fy.ssem.res,"PASS")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Second sem persentce :");
    scanf("%lf",&s.fy.ssem.per);
    fflush(stdin);
  }
  else if(strcmp(s.fy.ssem.res,"fail")==0|| strcmp(s.fy.ssem.res,"FAIL")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject name :");
    gets(s.fy.ssem.fail_sn);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject Code :");
    gets(s.fy.ssem.fail_sc);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Second sem persentce :");
    scanf("%lf",&s.fy.ssem.per);
    fflush(stdin);
  }
  else
  {
   printf("Valid result(pass/fail) :");
   goto abc2;
  }
}
 if(3==s.college.year)
 {
  printf("\n\t\t\t\t\t\t\t\t\t\tEnter First Semester Result (pass/fail) :");
  abc3:
  gets(s.fy.fsem.res);
  if(strcmp(s.fy.fsem.res,"pass")==0|| strcmp(s.fy.fsem.res,"PASS")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter First sem persentce :");
    scanf("%lf",&s.fy.fsem.per);
    fflush(stdin);
  }
  else if(strcmp(s.fy.fsem.res,"fail")==0|| strcmp(s.fy.fsem.res,"FAIL")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject name :");
    gets(s.fy.fsem.fail_sn);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject Code :");
    gets(s.fy.fsem.fail_sc);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter First sem persentce :");
    scanf("%lf",&s.fy.fsem.per);
    fflush(stdin);
  }
  else
  {
   printf("Valid result(pass/fail) :");
   goto abc3;
  }
  printf("\n\t\t\t\t\t\t\t\t\t\tEnter Second Semester Result (pass/fail) :");
  abc4:
  gets(s.fy.ssem.res);
  if(strcmp(s.fy.ssem.res,"pass")==0|| strcmp(s.fy.ssem.res,"PASS")==0)
  {
   printf("\n\t\t\t\t\t\t\t\t\t\tEnter Second sem persentce :");
   scanf("%lf",&s.fy.ssem.per);
   fflush(stdin);
  }
  else if(strcmp(s.fy.ssem.res,"fail")==0|| strcmp(s.fy.ssem.res,"FAIL")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject name :");
    gets(s.fy.ssem.fail_sn);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject Code :");
    gets(s.fy.ssem.fail_sc);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Second sem persentce :");
    scanf("%lf",&s.fy.ssem.per);
    fflush(stdin);
  }
  else
  {
   printf("Valid result(pass/fail) :");
   goto abc4;
  }
  printf("\n\t\t\t\t\t\t\t\t\t\tEnter Third Semester Result (pass/fail) :");
  abc5:
  gets(s.sy.tsem.res);
  if(strcmp(s.sy.tsem.res,"pass")==0|| strcmp(s.sy.tsem.res,"PASS")==0)
  {
   printf("\n\t\t\t\t\t\t\t\t\t\tEnter Third sem persentce :");
   scanf("%lf",&s.sy.tsem.per);
   fflush(stdin);
  }
  else if(strcmp(s.sy.tsem.res,"fail")==0|| strcmp(s.sy.tsem.res,"FAIL")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject name :");
    gets(s.sy.tsem.fail_sn);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject Code :");
    gets(s.sy.tsem.fail_sc);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter First sem persentce :");
    scanf("%lf",&s.sy.tsem.per);
    fflush(stdin);
  }
  else
  {
   printf("Valid result(pass/fail) :");
   goto abc5;
  }
  printf("\n\t\t\t\t\t\t\t\t\t\tEnter Fourth Semester Result (pass/fail) :");
  abc6:
  gets(s.sy.fosem.res);
  if(strcmp(s.sy.fosem.res,"pass")==0|| strcmp(s.sy.fosem.res,"PASS")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Fourth sem persentce :");
    scanf("%lf",&s.sy.fosem.per);
    fflush(stdin);
  }
  else if(strcmp(s.sy.fosem.res,"fail")==0|| strcmp(s.sy.fosem.res,"FAIL")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject name :");
    gets(s.sy.fosem.fail_sn);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject Code :");
    gets(s.sy.fosem.fail_sc);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter First sem persentce :");
    scanf("%lf",&s.sy.fosem.per);
    fflush(stdin);
  }
  else
  {
   printf("Valid result(pass/fail) :");
   goto abc6;
  }
 }
 if(4==s.college.year)
 {
  printf("\n\t\t\t\t\t\t\t\t\t\tEnter First Semester Result (pass/fail) :");
  abc7:
  gets(s.fy.fsem.res);
  if(strcmp(s.fy.fsem.res,"pass")==0|| strcmp(s.fy.fsem.res,"PASS")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter First sem persentce :");
    scanf("%lf",&s.fy.fsem.per);
    fflush(stdin);
  }
  else if(strcmp(s.fy.fsem.res,"fail")==0|| strcmp(s.fy.fsem.res,"FAIL")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject name :");
    gets(s.fy.fsem.fail_sn);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject Code :");
    gets(s.fy.fsem.fail_sc);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter First sem persentce :");
    scanf("%lf",&s.fy.fsem.per);
    fflush(stdin);
  }
  else
  {
   printf("Valid result(pass/fail) :");
   goto abc7;
  }
  printf("\n\t\t\t\t\t\t\t\t\t\tEnter Second Semester Result (pass/fail) :");
  abc8:
  gets(s.fy.ssem.res);
  if(strcmp(s.fy.ssem.res,"pass")==0|| strcmp(s.fy.ssem.res,"PASS")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Second sem persentce :");
    scanf("%lf",&s.fy.ssem.per);
  }
  else if(strcmp(s.fy.ssem.res,"fail")==0|| strcmp(s.fy.ssem.res,"FAIL")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject name :");
    gets(s.fy.ssem.fail_sn);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject Code :");
    gets(s.fy.ssem.fail_sc);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Second sem persentce :");
    scanf("%lf",&s.fy.ssem.per);
    fflush(stdin);
  }
  else
  {
   printf("Valid result(pass/fail) :");
   goto abc8;
  }
  printf("\n\t\t\t\t\t\t\t\t\t\tEnter Third Semester Result (pass/fail) :");
  abc9:
  gets(s.sy.tsem.res);
  if(strcmp(s.sy.tsem.res,"pass")==0|| strcmp(s.sy.tsem.res,"PASS")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Third sem persentce :");
    scanf("%lf",&s.sy.tsem.per);
    fflush(stdin);
  }
  else if(strcmp(s.sy.tsem.res,"fail")==0|| strcmp(s.sy.tsem.res,"FAIL")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject name :");
    gets(s.sy.tsem.fail_sn);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject Code :");
    gets(s.sy.tsem.fail_sc);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Third sem persentce :");
    scanf("%lf",&s.sy.tsem.per);
    fflush(stdin);
  }
  else
  {
   printf("Valid result(pass/fail) :");
   goto abc9;
  }
  printf("\n\t\t\t\t\t\t\t\t\t\tEnter Fourth Semester Result (pass/fail) :");
  abc10:
  gets(s.sy.fosem.res);
  if(strcmp(s.sy.fosem.res,"pass")==0|| strcmp(s.sy.fosem.res,"PASS")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Fourth sem persentce :");
    scanf("%lf",&s.sy.fosem.per);
    fflush(stdin);
  }
  else if(strcmp(s.sy.fosem.res,"fail")==0|| strcmp(s.sy.fosem.res,"FAIL")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject name :");
    gets(s.sy.fosem.fail_sn);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject Code :");
    gets(s.sy.fosem.fail_sc);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Fourth sem persentce :");
    scanf("%lf",&s.sy.fosem.per);
    fflush(stdin);
  }
  else
  {

printf("Valid result(pass/fail) :");
   goto abc10;
  }
   printf("\n\t\t\t\t\t\t\t\t\t\tEnter Fifth Semester Result (pass/fail) :");
   abc11:
   gets(s.ty.ffsem.res);
  if(strcmp(s.ty.ffsem.res,"pass")==0|| strcmp(s.ty.ffsem.res,"PASS")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Fifth sem persentce :");
    scanf("%lf",&s.ty.ffsem.per);
    fflush(stdin);
  }
  else if(strcmp(s.ty.ffsem.res,"fail")==0|| strcmp(s.ty.ffsem.res,"FAIL")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject name :");
    gets(s.ty.ffsem.fail_sn);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject Code :");
    gets(s.ty.ffsem.fail_sc);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Fifth sem persentce :");
    scanf("%lf",&s.ty.ffsem.per);
    fflush(stdin);
  }
  else
  {
   printf("Valid result(pass/fail) :");
   goto abc11;
  }
  printf("\n\t\t\t\t\t\t\t\t\t\tEnter Sixth Semester Result (pass/fail) :");
  abc12:
  gets(s.ty.sixsem.res);
  if(strcmp(s.ty.sixsem.res,"pass")==0|| strcmp(s.ty.sixsem.res,"PASS")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Sixth sem persentce :");
    scanf("%lf",&s.ty.sixsem.per);
    fflush(stdin);
  }
  else if(strcmp(s.ty.sixsem.res,"fail")==0|| strcmp(s.ty.sixsem.res,"FAIL")==0)
  {
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject name :");
    gets(s.ty.sixsem.fail_sn);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Back Subject Code :");
    gets(s.ty.sixsem.fail_sc);
    fflush(stdin);
    printf("\n\t\t\t\t\t\t\t\t\t\tEnter Sixth sem persentce :");
    scanf("%lf",&s.ty.sixsem.per);
    fflush(stdin);
  }
  else
  {
   printf("Valid result(pass/fail) :");
   goto abc12;
  }
 }

 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Bank Name: ");
 gets(s.acc_d.b_name);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Account  no.: ");
 gets(s.acc_d.acc_no);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter Branch Name: ");
 gets(s.acc_d.branch_name);
 fflush(stdin);
 printf("\n\t\t\t\t\t\t\t\t\t\tEnter IFSC Code: ");
 gets(s.acc_d.ifsc);
 fflush(stdin);
 fwrite(&s,sizeof(s),1,fp);
 printf("\n\t\t\t\t\t\t\t\t\t\t The record is sucessfully saved");
}
else
{
	printf("\n\t\t\t\t\t\t\t\t\t\t Sory,This Enrollment Number is alredy  found in the database");
}
fclose(fp);
getch();
}

void search_student()
{
  system("CLS");
  printf("\n\t\t\t\t\t\t\t\t\t\tStudent Name : %s %s %s",s.f_name,s.m_name,s.l_name);
  printf("\n\t\t\t\t\t\t\t\t\t\tEnrollment Number : %s",s.en);
  printf("\n\t\t\t\t\t\t\t\t\t\tDate Of Birth %d/%d/%d",s.dob.dd,s.dob.mm,s.dob.yy);
  printf("\n\t\t\t\t\t\t\t\t\t\tMobile Number :%s",s.m_no);
  printf("\n\t\t\t\t\t\t\t\t\t\tEmail Address :%s ",s.mail);
  printf("\n\t\t\t\t\t\t\t\t\t\tGender :%s",s.gen);
  printf("\n\t\t\t\t\t\t\t\t\t\tCast :%s",s.cast);
  printf("\n\t\t\t\t\t\t\t\t\t\tReligion :%s",s.religion);
  printf("\n\t\t\t\t\t\t\t\t\t\tAddress :%s %s %s %s %s %s%ld",s.ad.house_no,s.ad.street,s.ad.city,s.ad.district,s.ad.state,s.ad.country,s.ad.pin);
  printf("\n\t\t\t\t\t\t\t\t\t\tAadhar Card Number : %s",s.aadhar_card);
  printf("\n\t\t\t\t\t\t\t\t\t\tSamagra Id :%s",s.samagra_id);
  printf("\n\t\t\t\t\t\t\t\t\t\tIncome :%lf",s.parent.income);
  printf("\n\t\t\t\t\t\t\t\t\t\tFather Name :%s",s.parent.father_n);
  printf("\n\t\t\t\t\t\t\t\t\t\tFather Occupation :%s",s.parent.f_occup);
  printf("\n\t\t\t\t\t\t\t\t\t\tFather Mobile Number :%s",s.parent.f_no);
  printf("\n\t\t\t\t\t\t\t\t\t\tMother Name :%s",s.parent.mother_n);
  printf("\n\t\t\t\t\t\t\t\t\t\tMother Occupation :%s",s.parent.m_occup);
  printf("\n\t\t\t\t\t\t\t\t\t\tMother Number :%s",s.parent.m_no);
  printf("\n\t\t\t\t\t\t\t\t\t\t10th Persentage :%lf",s.p_exam_d.tenth);
  printf("\n\t\t\t\t\t\t\t\t\t\t12th Persentage :%lf",s.p_exam_d.towlth);
  printf("\n\t\t\t\t\t\t\t\t\t\tJEE Marks :%lf",s.p_exam_d.jee);
  printf("\n\t\t\t\t\t\t\t\t\t\tCollege Name :%s",s.college.college_name);
  printf("\n\t\t\t\t\t\t\t\t\t\tCourse Name :%s",s.college.course_name);
  printf("\n\t\t\t\t\t\t\t\t\t\tDepartment Name :%s",s.college.dept_name);
  printf("\n\t\t\t\t\t\t\t\t\t\tStudent Branch :%s",s.college.branch);
  printf("\n\t\t\t\t\t\t\t\t\t\tStudent Current Year :%d",s.college.year);
  printf("\n\t\t\t\t\t\t\t\t\t\tStudent Current Semester :%d",s.college.sem);
  printf("\n\t\t\t\t\t\t\t\t\t\tAdmission Status  :%s",s.college.ad_status);
  printf("\n\t\t\t\t\t\t\t\t\t\tAdmission Date :%d/%d/%d",s.college.ad_date.dd,s.college.ad_date.mm,s.college.ad_date.yy);
  printf("\n\t\t\t\t\t\t\t\t\t\tHostel Status  :%s",s.college.hs.h);
  if(strcmp(s.college.hs.h,"Hostler")==0)
     printf("\n\t\t\t\t\t\t\t\t\t\tRoom Number :%d",s.college.hs.no);
  else
     printf("\n\t\t\t\t\t\t\t\t\t\tBus Number :%d",s.college.hs.no);
  if(s.college.year==1);
  if(s.college.year==2)
  {
   printf("\n\t\t\t\t\t\t\t\t\t\tFirst Semester Result :%s",s.fy.fsem.res);
   printf("\n\t\t\t\t\t\t\t\t\t\tFirst Semester SGPA :%lf",s.fy.fsem.per);
   if(strcmp(s.fy.fsem.res,"fail")==0)
   {
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.fy.fsem.fail_sn);
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.fy.fsem.fail_sc);
   }
   printf("\n\t\t\t\t\t\t\t\t\t\tSecond Semester Result :%s",s.fy.ssem.res);
   printf("\n\t\t\t\t\t\t\t\t\t\tSecond Semester SGPA :%lf",s.fy.ssem.per);
   if(strcmp(s.fy.ssem.res,"fail")==0)
   {
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.fy.ssem.fail_sn);
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.fy.ssem.fail_sc);
   }
  }
  if(s.college.year==3)
  {
   printf("\n\t\t\t\t\t\t\t\t\t\tFirst Semester Result :%s",s.fy.fsem.res);
   printf("\n\t\t\t\t\t\t\t\t\t\tFirst Semester SGPA :%lf",s.fy.fsem.per);
   if(strcmp(s.fy.fsem.res,"fail")==0)
   {
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.fy.fsem.fail_sn);
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.fy.fsem.fail_sc);
   }
   printf("\n\t\t\t\t\t\t\t\t\t\tSecond Semester Result :%s",s.fy.ssem.res);
   printf("\n\t\t\t\t\t\t\t\t\t\tSecond Semester SGPA :%lf",s.fy.ssem.per);
   if(strcmp(s.fy.ssem.res,"fail")==0)
   {
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.fy.ssem.fail_sn);
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.fy.ssem.fail_sc);
   }
   printf("\n\t\t\t\t\t\t\t\t\t\tThird Semester Result :%s",s.sy.tsem.res);
   printf("\n\t\t\t\t\t\t\t\t\t\tThird Semester SGPA :%lf",s.sy.tsem.per);
   if(strcmp(s.sy.tsem.res,"fail")==0)
   {
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.sy.tsem.fail_sn);
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.sy.tsem.fail_sc);
   }
   printf("\n\t\t\t\t\t\t\t\t\t\tFourth Semester Result :%s",s.sy.fosem.res);
   printf("\n\t\t\t\t\t\t\t\t\t\tFourth Semester SGPA :%lf",s.sy.fosem.per);
   if(strcmp(s.sy.fosem.res,"fail")==0)
   {
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.sy.fosem.fail_sn);
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.sy.fosem.fail_sc);
   }
  }
  if(s.college.year==4)
  {
   printf("\n\t\t\t\t\t\t\t\t\t\tFirst Semester Result :%s",s.fy.fsem.res);
   printf("\n\t\t\t\t\t\t\t\t\t\tFirst Semester SGPA :%lf",s.fy.fsem.per);
   if(strcmp(s.fy.fsem.res,"fail")==0)
   {
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.fy.fsem.fail_sn);
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.fy.fsem.fail_sc);
   }
   printf("\n\t\t\t\t\t\t\t\t\t\tSecond Semester Result :%s",s.fy.ssem.res);
   printf("\n\t\t\t\t\t\t\t\t\t\tSecond Semester SGPA :%lf",s.fy.ssem.per);
   if(strcmp(s.fy.ssem.res,"fail")==0)
   {
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.fy.ssem.fail_sn);
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.fy.ssem.fail_sc);
   }
   printf("\n\t\t\t\t\t\t\t\t\t\tThird Semester Result :%s",s.sy.tsem.res);
   printf("\n\t\t\t\t\t\t\t\t\t\tThird Semester SGPA :%lf",s.sy.tsem.per);
   if(strcmp(s.sy.tsem.res,"fail")==0)
   {
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.sy.tsem.fail_sn);
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.sy.tsem.fail_sc);
   }
   printf("\n\t\t\t\t\t\t\t\t\t\tFourth Semester Result :%s",s.sy.fosem.res);
   printf("\n\t\t\t\t\t\t\t\t\t\tFourth Semester SGPA :%lf",s.sy.fosem.per);
   if(strcmp(s.sy.fosem.res,"fail")==0)
   {
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.sy.fosem.fail_sn);
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.sy.fosem.fail_sc);
   }
   printf("\n\t\t\t\t\t\t\t\t\t\tFifth Semester Result :%s",s.ty.ffsem.res);
   printf("\n\t\t\t\t\t\t\t\t\t\tFifth Semester SGPA :%lf",s.ty.ffsem.per);
   if(strcmp(s.ty.ffsem.res,"fail")==0)
   {
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.ty.ffsem.fail_sn);
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.ty.ffsem.fail_sc);
   }
   printf("\n\t\t\t\t\t\t\t\t\t\tSixth Semester Result :%s",s.ty.sixsem.res);
   printf("\n\t\t\t\t\t\t\t\t\t\tSixth Semester SGPA :%lf",s.ty.sixsem.per);
   if(strcmp(s.ty.sixsem.res,"fail")==0)
   {
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.ty.sixsem.fail_sn);
   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.ty.sixsem.fail_sc);
   }
  }
  printf("\n\t\t\t\t\t\t\t\t\t\tBank Name :%s",s.acc_d.b_name);
  printf("\n\t\t\t\t\t\t\t\t\t\tBank Account Number :%s",s.acc_d.acc_no);
  printf("\n\t\t\t\t\t\t\t\t\t\tBank Branch Name :%s",s.acc_d.branch_name);
  printf("\n\t\t\t\t\t\t\t\t\t\tBank IFSC Code :%s",s.acc_d.ifsc);
getch();
}


void searchbyen()
{
	char en[15];
	int isFound=0;
	printf("\n\t\t\t\t\t\t\t\t\t\t Enter Enrollment number :");
	fflush(stdin);
	gets(en);
	fp = fopen("student.txt","rb");
	rewind(fp);
	while(fread(&s,sizeof(s),1,fp) == 1)
	{
		if(strcmp(en,s.en) == 0)
		{
			isFound = 1;
			search_student();
			break;
		}
	}
	if(isFound==0)
	{
		printf("\n\t\t\t\t\t\t\t\t\t\t Sory, No record found in the database");	
	}
	fclose(fp);
	getch();
}

void searchbyname()
{
	char fn[15],ln[15];
	int isFound=0;
    printf("\n\t\t\t\t\t\t\t\t\t\t Enter First Name :");
	fflush(stdin);
	gets(fn);
	printf("\n\t\t\t\t\t\t\t\t\t\t Enter Last Name :");
	fflush(stdin);
	gets(ln);

	fp = fopen("student.txt","rb");
	rewind(fp);
	while(fread(&s,sizeof(s),1,fp) == 1)
	{
		if((strcmp(fn,s.f_name)==0)&&(strcmp(ln,s.l_name)==0))
		{
			isFound = 1;
			search_student();
	  	}
	}
	if(isFound==0)
	{
		printf("\n\t\t\t\t\t\t\t\t\t\t Sory, No record found in the database");	
	}
	fclose(fp);
	getch();
}
void searchbybranch()
{
	char b[5];
	int isFound=0;
	printf("\n\t\t\t\t\t\t\t\t\t\t Enter Branch(cs/it/ce/me/ex) :");
	fflush(stdin);
	gets(b);
	fp = fopen("student.txt","rb");
	rewind(fp);
	while(fread(&s,sizeof(s),1,fp) == 1)
	{
		if(strcmp(b,s.college.branch)==0)
		{
			isFound = 1;
			search_student();
	    }
	}
	if(isFound==0)
    {
		printf("\n\t\t\t\t\t\t\t\t\t\t Sory, No record found in the database");
    }
	fclose(fp);
	getch();
}


void searchbypin()
{
	long int pin;
    int isFound=0;
    printf("\n\t\t\t\t\t\t\t\t\t\t Enter Your Pin code :");
	fflush(stdin);
	scanf("%ld",&pin);
	fp = fopen("student.txt","rb");
	rewind(fp);
	while(fread(&s,sizeof(s),1,fp) == 1)
    {
		if(pin==s.ad.pin)
		{
			isFound = 1;
			search_student();
	    }
	}
	if(isFound==0)
	{
		printf("\n\t\t\t\t\t\t\t\t\t\t Sory, No record found in the database");
	}
	fclose(fp);
	getch();
}

void searchbycast()
{
	char cast[15];
	int isFound=0;
    printf("\n\t\t\t\t\t\t\t\t\t\t Enter Your cast(general/obc/st/sc):");
	fflush(stdin);
	gets(cast);
	fp = fopen("student.txt","rb");
	rewind(fp);
	while(fread(&s,sizeof(s),1,fp) == 1)
	{
		if(strcmp(cast,s.cast)==0)
		{
			isFound = 1;
			search_student();
	    }
   }
   if(isFound==0)
   {
		printf("\n\t\t\t\t\t\t\t\t\t\t Sory, No record found in the database");
   }
   fclose(fp);
	getch();
}
void display()
{
 system("CLS");
 fp=fopen("student.txt","rb");
 if(fp==NULL)
 {
  printf("\n\t\t\t\t\t\t\t\t\t\t File not open");
  exit(1);
 }
 rewind(fp);
 while(fread(&s,sizeof(s),1,fp) == 1)
 {
 		
	  system("CLS");	
	  printf("\n\n\n\t\t\t\t\t\t\t\t\t\tStudent Name : %s %s %s",s.f_name,s.m_name,s.l_name);
	  printf("\n\t\t\t\t\t\t\t\t\t\tEnrollment Number : %s",s.en);
	  printf("\n\t\t\t\t\t\t\t\t\t\tDate Of Birth %d/%d/%d",s.dob.dd,s.dob.mm,s.dob.yy);
	  printf("\n\t\t\t\t\t\t\t\t\t\tMobile Number :%s",s.m_no);
	  printf("\n\t\t\t\t\t\t\t\t\t\tEmail Address :%s ",s.mail);
	  printf("\n\t\t\t\t\t\t\t\t\t\tGender :%s",s.gen);
	  printf("\n\t\t\t\t\t\t\t\t\t\tCast :%s",s.cast);
	  printf("\n\t\t\t\t\t\t\t\t\t\tReligion :%s",s.religion);
	  printf("\n\t\t\t\t\t\t\t\t\t\tAddress :%s %s, %s, %s, %s, %s, %ld",s.ad.house_no,s.ad.street,s.ad.city,s.ad.district,s.ad.state,s.ad.country,s.ad.pin);
	  printf("\n\t\t\t\t\t\t\t\t\t\tAadhar Card Number : %s",s.aadhar_card);
	  printf("\n\t\t\t\t\t\t\t\t\t\tSamagra Id :%s",s.samagra_id);
	  printf("\n\t\t\t\t\t\t\t\t\t\tIncome :%lf",s.parent.income);
	  printf("\n\t\t\t\t\t\t\t\t\t\tFather Name :%s",s.parent.father_n);
	  printf("\n\t\t\t\t\t\t\t\t\t\tFather Occupation :%s",s.parent.f_occup);
	  printf("\n\t\t\t\t\t\t\t\t\t\tFather Mobile Number :%s",s.parent.f_no);
	  printf("\n\t\t\t\t\t\t\t\t\t\tMother Name :%s",s.parent.mother_n);
	  printf("\n\t\t\t\t\t\t\t\t\t\tMother Occupation :%s",s.parent.m_occup);
	  printf("\n\t\t\t\t\t\t\t\t\t\tMother Number :%s",s.parent.m_no);
	  printf("\n\t\t\t\t\t\t\t\t\t\t10th Persentage :%lf",s.p_exam_d.tenth);
	  printf("\n\t\t\t\t\t\t\t\t\t\t12th Persentage :%lf",s.p_exam_d.towlth);
	  printf("\n\t\t\t\t\t\t\t\t\t\tJEE Marks :%lf",s.p_exam_d.jee);
	  printf("\n\t\t\t\t\t\t\t\t\t\tCollege Name :%s",s.college.college_name);
	  printf("\n\t\t\t\t\t\t\t\t\t\tCourse Name :%s",s.college.course_name);
	  printf("\n\t\t\t\t\t\t\t\t\t\tDepartment Name :%s",s.college.dept_name);
	  printf("\n\t\t\t\t\t\t\t\t\t\tStudent Branch :%s",s.college.branch);
	  printf("\n\t\t\t\t\t\t\t\t\t\tStudent Current Year :%d",s.college.year);
	  printf("\n\t\t\t\t\t\t\t\t\t\tStudent Current Semester :%d",s.college.sem);
	  printf("\n\t\t\t\t\t\t\t\t\t\tAdmission Status  :%s",s.college.ad_status);
	  printf("\n\t\t\t\t\t\t\t\t\t\tAdmission Date :%d/%d/%d",s.college.ad_date.dd,s.college.ad_date.mm,s.college.ad_date.yy);
	  printf("\n\t\t\t\t\t\t\t\t\t\tHostel Status  :%s",s.college.hs.h);
	  if(strcmp(s.college.hs.h,"Hostler")==0)
	     printf("\n\t\t\t\t\t\t\t\t\t\tRoom Number :%d",s.college.hs.no);
	  else
	     printf("\n\t\t\t\t\t\t\t\t\t\tBus Number :%d",s.college.hs.no);
	  if(s.college.year==1);
	  if(s.college.year==2)
	  {
	   printf("\n\t\t\t\t\t\t\t\t\t\tFirst Semester Result :%s",s.fy.fsem.res);
	   printf("\n\t\t\t\t\t\t\t\t\t\tFirst Semester SGPA :%lf",s.fy.fsem.per);
	   if(strcmp(s.fy.fsem.res,"fail")==0)
	   {
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.fy.fsem.fail_sn);
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.fy.fsem.fail_sc);
	   }
	   printf("\n\t\t\t\t\t\t\t\t\t\tSecond Semester Result :%s",s.fy.ssem.res);
	   printf("\n\t\t\t\t\t\t\t\t\t\tSecond Semester SGPA :%lf",s.fy.ssem.per);
	   if(strcmp(s.fy.ssem.res,"fail")==0)
	   {
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.fy.ssem.fail_sn);
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.fy.ssem.fail_sc);
	   }
	  }
	  if(s.college.year==3)
	  {
	   printf("\n\t\t\t\t\t\t\t\t\t\tFirst Semester Result :%s",s.fy.fsem.res);
	   printf("\n\t\t\t\t\t\t\t\t\t\tFirst Semester SGPA :%lf",s.fy.fsem.per);
	   if(strcmp(s.fy.fsem.res,"fail")==0)
	   {
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.fy.fsem.fail_sn);
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.fy.fsem.fail_sc);
	   }
	   printf("\n\t\t\t\t\t\t\t\t\t\tSecond Semester Result :%s",s.fy.ssem.res);
	   printf("\n\t\t\t\t\t\t\t\t\t\tSecond Semester SGPA :%lf",s.fy.ssem.per);
	   if(strcmp(s.fy.ssem.res,"fail")==0)
	   {
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.fy.ssem.fail_sn);
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.fy.ssem.fail_sc);
	   }
	   printf("\n\t\t\t\t\t\t\t\t\t\tThird Semester Result :%s",s.sy.tsem.res);
	   printf("\n\t\t\t\t\t\t\t\t\t\tThird Semester SGPA :%lf",s.sy.tsem.per);
	   if(strcmp(s.sy.tsem.res,"fail")==0)
	   {
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.sy.tsem.fail_sn);
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.sy.tsem.fail_sc);
	   }
	   printf("\n\t\t\t\t\t\t\t\t\t\tFourth Semester Result :%s",s.sy.fosem.res);
	   printf("\n\t\t\t\t\t\t\t\t\t\tFourth Semester SGPA :%lf",s.sy.fosem.per);
	   if(strcmp(s.sy.fosem.res,"fail")==0)
	   {
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.sy.fosem.fail_sn);
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.sy.fosem.fail_sc);
	   }
	  }
	  if(s.college.year==4)
	  {
	   printf("\n\t\t\t\t\t\t\t\t\t\tFirst Semester Result :%s",s.fy.fsem.res);
	   printf("\n\t\t\t\t\t\t\t\t\t\tFirst Semester SGPA :%lf",s.fy.fsem.per);
	   if(strcmp(s.fy.fsem.res,"fail")==0)
	   {
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.fy.fsem.fail_sn);
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.fy.fsem.fail_sc);
	   }
	   printf("\n\t\t\t\t\t\t\t\t\t\tSecond Semester Result :%s",s.fy.ssem.res);
	   printf("\n\t\t\t\t\t\t\t\t\t\tSecond Semester SGPA :%lf",s.fy.ssem.per);
	   if(strcmp(s.fy.ssem.res,"fail")==0)
	   {
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.fy.ssem.fail_sn);
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.fy.ssem.fail_sc);
	   }
	   printf("\n\t\t\t\t\t\t\t\t\t\tThird Semester Result :%s",s.sy.tsem.res);
	   printf("\n\t\t\t\t\t\t\t\t\t\tThird Semester SGPA :%lf",s.sy.tsem.per);
	   if(strcmp(s.sy.tsem.res,"fail")==0)
	   {
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.sy.tsem.fail_sn);
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.sy.tsem.fail_sc);
	   }
	   printf("\n\t\t\t\t\t\t\t\t\t\tFourth Semester Result :%s",s.sy.fosem.res);
	   printf("\n\t\t\t\t\t\t\t\t\t\tFourth Semester SGPA :%lf",s.sy.fosem.per);
	   if(strcmp(s.sy.fosem.res,"fail")==0)
	   {
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.sy.fosem.fail_sn);
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.sy.fosem.fail_sc);
	   }
	   printf("\n\t\t\t\t\t\t\t\t\t\tFifth Semester Result :%s",s.ty.ffsem.res);
	   printf("\n\t\t\t\t\t\t\t\t\t\tFifth Semester SGPA :%lf",s.ty.ffsem.per);
	   if(strcmp(s.ty.ffsem.res,"fail")==0)
	   {
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.ty.ffsem.fail_sn);
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.ty.ffsem.fail_sc);
	   }
	   printf("\n\t\t\t\t\t\t\t\t\t\tSixth Semester Result :%s",s.ty.sixsem.res);
	   printf("\n\t\t\t\t\t\t\t\t\t\tSixth Semester SGPA :%lf",s.ty.sixsem.per);
	   if(strcmp(s.ty.sixsem.res,"fail")==0)
	   {
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Name :%s",s.ty.sixsem.fail_sn);
	   printf("\n\t\t\t\t\t\t\t\t\t\t Back Subject Code :%s",s.ty.sixsem.fail_sc);
	   }
	  }
	  printf("\n\t\t\t\t\t\t\t\t\t\tBank Name :%s",s.acc_d.b_name);
	  printf("\n\t\t\t\t\t\t\t\t\t\tBank Account Number :%s",s.acc_d.acc_no);
	  printf("\n\t\t\t\t\t\t\t\t\t\tBank Branch Name :%s",s.acc_d.branch_name);
	  printf("\n\t\t\t\t\t\t\t\t\t\tBank IFSC Code :%s",s.acc_d.ifsc);
		getch(); 
	  }
  fclose(fp);
getch();
}
int delete_student(char *en)
{
    FILE *temp;
    int isFound=0;
	system("CLS");
    fp = fopen("student.txt","rb");
	while(fread(&s, sizeof(s),1,fp) == 1)
	{
        if(strcmp(en,s.en) == 0)
		{    
			isFound = 1;
            break;
        }
    }
    fclose(fp);
    if(isFound==1)
	{
   		 fp = fopen("student.txt","rb+");
		 temp = fopen("mp.txt", "wb+");
		 while(fread(&s, sizeof(s),1,fp) == 1)
		 {
	        if(strcmp(en,s.en) != 0)
			{
	            fwrite(&s,sizeof(s),1,temp);
	        }
	    }
	    fclose(fp);
	    fclose(temp);
		if(remove("student.txt")== 0 )
	   	{
	   		printf("\n\t\t\t\t\t\t\t\t\t\t The record is sucessfully deleted");	
			rename("mp.txt","student.txt");		
		}
		else
		{
          printf( "\n\t\t\t\t\t\t\t\t\t\t Error deleting file" );
          getch();
          return 0;
		}
		rename("mp.txt","student.txt");
		getch();	
		return isFound;
	}
	
	else
		{
			printf( "\n\t\t\t\t\t\t\t\t\t\t No Record Found" );
			getch();
			return isFound;
		}
}

void mod_student(char *en)
{
    FILE *temp;
    int isFound = 0;
    system("CLS");
    fp = fopen("student.txt","rb+");
    while(fread(&s, sizeof(s),1,fp) == 1)
	{
        if(strcmp(en,s.en) == 0)
		{    
			isFound = 1;
            break;
        }
    }
    fclose(fp);
    if(isFound==1)
	{
	 if(delete_student(en))
	 		insert(en);
	}
	else
	{
	printf("\n\t\t\t\t\t\t\t\t\t\t No Record Found");
    }
    
    getch();
}

int main()
{
	int c;
	int ch;
    system("CLS");
    password();
	while(1)
	{
		a1:
	    system("CLS");
		printf("\n\n\n\n\n\t\t\t\t\t\t\t\t\t\t Student Record Menagement System");
		printf("\n\n\t\t\t\t\t\t\t\t*****************************************************************************");
		printf("\n\n\n\t\t\t\t\t\t\t\t\t\t<1> Insert Student Record");
		printf("\n\n\t\t\t\t\t\t\t\t\t\t<2> Remove Student Record");
		printf("\n\n\t\t\t\t\t\t\t\t\t\t<3> Search Student Record");
		printf("\n\n\t\t\t\t\t\t\t\t\t\t<4> View Record's list");
		printf("\n\n\t\t\t\t\t\t\t\t\t\t<5> Modify Student Record");
		printf("\n\n\t\t\t\t\t\t\t\t\t\t<6> Close Application");
		printf("\n\n\n\t\t\t\t\t\t\t\t\t\t  Enter your choice:");
		fflush(stdin);
		scanf("%[1-6]d",&c);
		switch(c)
		{
			case '1':
			{
				char en[15];
				system("CLS");
				printf("\n\t\t\t\t\t\t\t\t\t\t Enter Enrollment number :");
				fflush(stdin);
				gets(en);
		 		insert(en);
				break;
		   }
			case '2':
			{
				char en[15];
				system("CLS");
				printf("\n\n\n\n\t\t\t\t\t\t\t\t\t\t Delete Record");
			    printf("\n\n\t\t\t\t\t\t\t\t*****************************************************************************");
				printf("\n\n\n\t\t\t\t\t\t\t\t\t\t Enter Enrollment number to Remove: ");
				fflush(stdin);
			    gets(en);
				delete_student(en);
				break;
			}
			case '3':
			{
				while(1)
			   {
				    a2:
					system("CLS");
					printf("\n\n\n\n\n\t\t\t\t\t\t\t\t\t\t SEARCH STUDENT RECORDS");
					printf("\n\n\n\t\t\t\t\t\t\t\t*****************************************************************************");
					printf("\n\n\t\t\t\t\t\t\t\t\t\t<a> Student Record searching by Enrollment number :  ");
					printf("\n\n\t\t\t\t\t\t\t\t\t\t<b> Student Record searching by Name :");
					printf("\n\n\t\t\t\t\t\t\t\t\t\t<c> Student Record searching by Branch :");
					printf("\n\n\t\t\t\t\t\t\t\t\t\t<d> Student Record searching by Address(pincode only) :");
					printf("\n\n\t\t\t\t\t\t\t\t\t\t<e> Student Record searching by cast ");
					printf("\n\n\t\t\t\t\t\t\t\t\t\t<f> Close Application");
					printf("\n\n\n\t\t\t\t\t\t\t\t\t\t  Enter your choice:");
					fflush(stdin);
					scanf("%[a,b,c,d,e,f]c",&ch);
					switch(ch)
					{
						case 'a':
						{
							searchbyen();
							break;
						}
						case 'b':
						{
							searchbyname();
							break;
						}
						case 'c':
						{
							searchbybranch();
							break;
						}
					    case 'd':
					   {
							searchbypin();
							break;
					   }
						case 'e':
						{
							searchbycast();
							break;
					    }
						case 'f':
						{
							goto a1;
	 				    }
						default :
						    goto a2;
					}
				}
	
			}
			case '4':
			{
				display();
				break;
			}
			case '5':
			{
				char en[15];
				system("CLS");
			    printf("\n\n\n\n\t\t\t\t\t\t\t\t\t\t Modify the Record");
				printf("\n\n\t\t\t\t\t\t\t\t*****************************************************************************");
				printf("\n\n\n\t\t\t\t\t\t\t\t\t\tEnter Enrollment Number to Modify : ");
				fflush(stdin);
    			gets(en);
				mod_student(en);
				break;
			}
			case '6':
			{
				exit(1);
			}
			default :
			{
				goto a1;
			}
		}
	}
}
















